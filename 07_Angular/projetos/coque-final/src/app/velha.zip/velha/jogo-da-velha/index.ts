export * from './jogo-da-velha.component';
